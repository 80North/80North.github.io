---
layout: post
title:	"Quick Video on Internet Freedom for USA Readers"
date:	2017-12-03
excerpt: "https://player.vimeo.com/video/223515967"
image: "/images/Posts/Break-The-Net/call.png"
---

<iframe src="https://player.vimeo.com/video/223515967" width="640" height="360" frameborder="0" webkitallowfullscreen mozallowfullscreen allowfullscreen></iframe>
<p><a href="https://vimeo.com/223515967">Battle For The Net Video Bumper</a> from <a href="https://vimeo.com/user68238598">FFTF</a> on <a href="https://vimeo.com">Vimeo</a>.</p>